Fragments
=========

Fragments is a collection of 3D models which is made for using with the particle
system in Unity (Shuriken).

![screencast](http://keijiro.github.io/Fragments/screencast.gif)

License
-------

This work is in the public domain. Everyone is free to use, modify, republish,
sell or give away the assets in this repository
