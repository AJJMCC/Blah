SketchyFx
=========

This is an attempt at making a sketch filter only with the standard assets in Unity.

![Screenshot][preview]

[Video (vimeo.com)][vimeo]


Acknowledgements
----------------

- Pencil texture (pencil1-8.png) by [Washu-m][pencil]
- Paper texture (OTF_Crumpled_Paper_08.jpg) by [Brent Leimenstoll][paper]
- Space Robot Kyle by [Kyle Brewer (provided from Unity Technologies)][kyle]

[preview]: http://keijiro.github.io/SketchyFx/screenshot.png
[vimeo]:   http://vimeo.com/97597887
[pencil]:  http://washu-m.deviantart.com/art/1-5-Pencil-2b-blue-zig-zag-Texture-346889452
[paper]:   http://www.outsidethefray.com/2013/02/10-crumpled-paper-textures/
[kyle]:    http://www.assetstore.unity3d.com/en/#!/content/4696
